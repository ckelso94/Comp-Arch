Building:
	Run make
	Requires a GCC version that supports C11

Usage:
	./main.exe prog.bin

Files:
	main.c: Initialization and runs main loop	
	stages.h: Defines main functions and structures of each stage
	IF.c: Fetch stage
	ID.c: Decode stage
	EXE.c: Execute stage
	MEM.c: Memory stage
	WB.c: Writeback stage

	test.s: The source file of the assembly program
	prog.bin: test.s compiled into a binary file
	prog-hex.txt: Hexdump of prog.bin

	makefile: Builds simulator

	README.txt: Documentation
