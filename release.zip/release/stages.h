#ifndef STAGES_H
#define STAGES_H
#include <stdint.h>

#define MEM_SIZE 512

typedef struct
{
	//the instruction, not the address
	uint16_t instr;
	//the value of the next PC (actually PC+2)
	uint16_t PC;
} IF_ID_Buffer;

typedef struct
{
	//the two registers from reg_file
	uint16_t rs,rt;
	//the instruction, needed for const/jumps
	uint16_t instr;
	//PC+4 from IF_ID
	uint16_t PC;
	//control values
	uint8_t ALU_src,slt_ctrl,skip,skip_value,jump,ALU_op,
			mem_write,mem_read,
			mem_to_reg,reg_dst,reg_write;
} ID_EXE_Buffer;

typedef struct
{
	//output from the ALU
	uint16_t ALU_out;
	//value of rt, used for writing
	uint16_t rt_val;
	//addresses of rt and rd, needed by WB
	uint8_t rt,rd;
	//next PC value
	uint16_t next_PC;
	//control values
	uint8_t mem_write,mem_read,
	        mem_to_reg,reg_dst,reg_write;

} EXE_MEM_Buffer;

typedef struct
{
	//memory data to possibly be written back
	uint16_t mem_data;
	//alu output to possibly be written back
	uint16_t ALU_data;
	//possible registers to write to
	uint8_t rt,rd;
	//control values
	uint8_t mem_to_reg,reg_dst,reg_write;
} MEM_WB_Buffer;

//PC is just a pointer, we need it to possible modify the PC value across stages
void IF_stage(uint16_t PC, uint16_t *instr_mem, IF_ID_Buffer *out_buf);
void ID_stage(IF_ID_Buffer *in_buf, ID_EXE_Buffer *old_buf, uint16_t *reg_file, uint8_t *load_hazard, ID_EXE_Buffer *out_buf);
void EXE_stage(ID_EXE_Buffer *in_buf, uint16_t *PC, uint8_t *skip_next, EXE_MEM_Buffer *out_buf, EXE_MEM_Buffer *mem_read_buf, MEM_WB_Buffer *wb_read_buf);
void MEM_stage(EXE_MEM_Buffer *in_buf, uint16_t *data_mem, MEM_WB_Buffer *out_buf);
void WB_stage(MEM_WB_Buffer *in_buf, uint16_t *reg_file);

#endif
